package com.aieraserx.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF080B18)
private val Panel = Color(0xFF141A2E)
private val Purple = Color(0xFF9565FF)
private val Cyan = Color(0xFF35D9E8)
private val Muted = Color(0xFF9AA6C5)

data class ToolItem(val title: String, val subtitle: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val tag: String = "AI")

private val tools = listOf(
    ToolItem("Magic Eraser", "Remove unwanted objects", Icons.Default.AutoFixHigh),
    ToolItem("Object Remover", "Erase selected objects", Icons.Default.DeleteSweep),
    ToolItem("Human Remover", "Clean up photo background", Icons.Default.PersonOff),
    ToolItem("Background Remover", "Cut out the subject", Icons.Default.LayersClear),
    ToolItem("Background Changer", "Replace the scene", Icons.Default.Wallpaper),
    ToolItem("Photo Enhancer", "Improve image clarity", Icons.Default.AutoAwesome),
    ToolItem("HD Upscaler", "Increase image resolution", Icons.Default.HighQuality),
    ToolItem("Text Remover", "Clear unwanted text", Icons.Default.TextFields),
    ToolItem("Photo Restore", "Refresh old photographs", Icons.Default.Restore),
    ToolItem("Magic Brush", "Paint the removal area", Icons.Default.Brush, "EDIT"),
    ToolItem("Blur Background", "Create portrait depth", Icons.Default.Portrait),
    ToolItem("Color Fix", "Tune image colors", Icons.Default.ColorLens, "EDIT")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EraserXApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EraserXApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTool by remember { mutableStateOf<ToolItem?>(null) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var brushSize by remember { mutableFloatStateOf(32f) }
    var busy by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            imageUri = uri
            scope.launch {
                bitmap = withContext(Dispatchers.IO) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.isMutableRequired = false
                    }
                }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Cyan, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink) { padding ->
            if (selectedTool == null) {
                Column(
                    Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp)
                ) {
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                                .background(Brush.linearGradient(listOf(Purple, Cyan))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.AutoFixHigh, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("AI ERASER X", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("CREATIVE STUDIO", fontSize = 10.sp, color = Muted, letterSpacing = 2.sp)
                        }
                        IconButton(onClick = { showInfo = true }) { Icon(Icons.Default.Info, "About", tint = Muted) }
                    }
                    Spacer(Modifier.height(22.dp))
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF30235E), Color(0xFF122E49), Panel)))
                            .border(1.dp, Color(0xFF5B5C9C), RoundedCornerShape(28.dp))
                            .padding(22.dp)
                    ) {
                        Column {
                            Text("MAKE EVERY PHOTO", color = Color(0xFFC8B8FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("PERFECT.", fontSize = 34.sp, fontWeight = FontWeight.Black, lineHeight = 38.sp)
                            Text("Your pocket-sized AI photo studio.", color = Color(0xFFD0D6EA), fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = { picker.launch("image/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Ink),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Choose a Photo", fontWeight = FontWeight.Bold)
                            }
                        }
                        Icon(Icons.Default.AutoAwesome, null, tint = Color(0x557FE9F0), modifier = Modifier.align(Alignment.BottomEnd).size(92.dp))
                    }
                    Spacer(Modifier.height(24.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("AI TOOLKIT", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${tools.size} TOOLS", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxWidth().height(540.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        userScrollEnabled = false
                    ) {
                        items(tools) { tool ->
                            ToolCard(tool) { selectedTool = tool }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("AI-powered editing workspace • Built for creators", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                }
            } else {
                EditorScreen(
                    tool = selectedTool!!,
                    bitmap = bitmap,
                    brushSize = brushSize,
                    onBrushChange = { brushSize = it },
                    onBack = { selectedTool = null },
                    onPick = { picker.launch("image/*") },
                    onSave = {
                        val b = bitmap
                        if (b != null) {
                            scope.launch {
                                val saved = withContext(Dispatchers.IO) { saveBitmap(context, b) }
                                Toast.makeText(context, if (saved) "Photo saved to Pictures" else "Could not save photo", Toast.LENGTH_LONG).show()
                            }
                        } else Toast.makeText(context, "Choose a photo first", Toast.LENGTH_SHORT).show()
                    },
                    onRun = {
                        Toast.makeText(context, "Connect an AI model/API to enable ${selectedTool!!.title}. See README.", Toast.LENGTH_LONG).show()
                    }
                )
            }
            if (showInfo) {
                AlertDialog(
                    onDismissRequest = { showInfo = false },
                    title = { Text("About AI Eraser X") },
                    text = { Text("Premium photo-editing starter app. AI tools need a connected model or API to process images.") },
                    confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } }
                )
            }
        }
    }
}

@Composable
fun ToolCard(tool: ToolItem, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, label = "cardScale")
    Column(
        Modifier.fillMaxWidth().scale(scale).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF202747), Panel)))
            .border(1.dp, Color(0xFF303B60), RoundedCornerShape(22.dp))
            .clickable { onClick() }.padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(Purple.copy(alpha = .35f), Cyan.copy(alpha = .22f)))),
                contentAlignment = Alignment.Center) {
                Icon(tool.icon, null, tint = Cyan, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.weight(1f))
            Text(tool.tag, color = Purple, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(13.dp))
        Text(tool.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(tool.subtitle, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
    }
}

@Composable
fun EditorScreen(
    tool: ToolItem, bitmap: Bitmap?, brushSize: Float, onBrushChange: (Float) -> Unit,
    onBack: () -> Unit, onPick: () -> Unit, onSave: () -> Unit, onRun: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text(tool.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("EDITING WORKSPACE", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            IconButton(onClick = onSave) { Icon(Icons.Default.SaveAlt, "Save", tint = Cyan) }
        }
        Spacer(Modifier.height(16.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF101528)).border(1.dp, Color(0xFF34405F), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                Image(bitmap.asImageBitmap(), null, modifier = Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.AddPhotoAlternate, null, tint = Muted, modifier = Modifier.size(54.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No photo selected", color = Muted)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = onPick) { Text("Choose from Gallery") }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        if (tool.title.contains("Brush")) {
            Text("Brush size  •  ${brushSize.toInt()} px", color = Muted, fontSize = 12.sp)
            Slider(value = brushSize, onValueChange = onBrushChange, valueRange = 8f..100f)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onPick, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Image, null); Spacer(Modifier.width(5.dp)); Text("Photo")
            }
            OutlinedButton(onClick = { }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Undo, null); Spacer(Modifier.width(5.dp)); Text("Undo")
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onRun, modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) {
            Icon(Icons.Default.AutoFixHigh, null)
            Spacer(Modifier.width(8.dp))
            Text("Run ${tool.title}", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("AI processing requires a configured model/API. See project README.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

private fun saveBitmap(context: android.content.Context, bitmap: Bitmap): Boolean {
    return try {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "AI_Eraser_X_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Eraser X")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: return false
        true
    } catch (_: Exception) { false }
}
