# AI Eraser X — Android Studio Project

Premium dark, 3D-inspired Android photo editing starter built with Kotlin + Jetpack Compose.

## Included
- Premium dashboard with 12 tool cards
- Android gallery photo picker
- Preview selected photo in editor workspace
- Brush-size control for Magic Brush workspace
- Save selected image to `Pictures/AI Eraser X`
- AI integration entry point and clear UI messaging
- Undo/Redo and processing integration points for future implementation

## Important: AI processing
This ZIP is a working Android app starter, not a trained AI model. Object removal, human removal,
background removal, text removal, enhancement and upscaling require an actual on-device model
or a secure backend API. The current `Run` action intentionally shows a setup message instead of
pretending that image processing has happened.

### Recommended integration
1. Create a backend endpoint, for example `POST /api/image-edit`.
2. Send the selected image plus an operation name and (for erase) a mask.
3. Return the processed image bytes or a secure result URL.
4. Replace the `onRun` toast in `MainActivity.kt` with a Retrofit/OkHttp request.
5. Keep API secrets on the backend; do not hardcode private keys in the Android app.

Suggested operations: `object_remove`, `human_remove`, `background_remove`,
`background_replace`, `text_remove`, `enhance`, `upscale`, `restore`.

## Build
- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35
- Open this folder in Android Studio and allow Gradle sync.
- Run on Android 7.0 (API 24) or newer.

## Project structure
- `app/src/main/java/com/aieraserx/app/MainActivity.kt` — app UI and photo workflow
- `app/src/main/AndroidManifest.xml` — Android app manifest
- `app/build.gradle.kts` — Android dependencies
