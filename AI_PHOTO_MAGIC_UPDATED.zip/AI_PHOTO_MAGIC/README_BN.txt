AI PHOTO MAGIC — UPDATED ZIP

লগইন:
Username: ADMIN
Password: 894261

চালানোর নিয়ম:
1. ZIP ফাইলটি Extract করুন।
2. AI_PHOTO_MAGIC/index.html ফাইলটি Android ফোনের Chrome বা অন্য ব্রাউজারে খুলুন।
3. Username ও Password লিখে প্রবেশ করুন।

ফিচার:
- Username এবং ৬ সংখ্যার Password লগইন
- JPG/PNG/WEBP ছবি আপলোড
- 4K long-edge resize (সর্বোচ্চ পাশ 3840px)
- ব্রাশ দিয়ে রঙের সাহায্যে অংশ মুছুন
- PNG হিসেবে ডাউনলোড
- ছবি ব্রাউজারেই প্রসেস হয়

সীমাবদ্ধতা:
- এটি ব্রাউজার-ভিত্তিক প্রোটোটাইপ; আসল AI super-resolution বা AI object removal নয়।
- Eraser নির্বাচিত রং দিয়ে অংশ ঢাকে; ব্যাকগ্রাউন্ড স্বয়ংক্রিয়ভাবে তৈরি করে না।
- HTML/JavaScript-এ রাখা Username ও Password নিরাপদ সার্ভার লগইন নয়; ফাইল দেখা বা সম্পাদনা করতে জানলে এগুলো দেখা যায়।
